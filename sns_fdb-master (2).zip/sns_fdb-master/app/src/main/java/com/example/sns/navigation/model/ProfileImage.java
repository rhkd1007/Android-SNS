package com.example.sns.navigation.model;

public class ProfileImage {
    private String imageUri;
    public ProfileImage(){
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }
}
